﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCReader.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";

            return View();
        }

        public ActionResult Scan(string imageData)
        {
            byte[] data = Convert.FromBase64String(imageData);

            Image image;
            using (MemoryStream ms = new MemoryStream(data))
            {
                image = Image.FromStream(ms);
            }

            var barcodeReader = new ZXing.BarcodeReader();

            // create an in memory bitmap
            var barcodeBitmap = (Bitmap)image;

            // decode the barcode from the in memory bitmap
            var barcodeResult = barcodeReader.Decode(barcodeBitmap);
            ViewBag.Result = $"Decoded barcode text: {barcodeResult?.Text}";
            ViewBag.Type = $"Barcode format: {barcodeResult?.BarcodeFormat}";
            return null;
        }
    }
}
