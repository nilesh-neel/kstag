﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BarcodeReader
{
    class Program
    {
        static void Main(string[] args)
        { // create a barcode reader instance
            var barcodeReader = new ZXing.BarcodeReader();

            // create an in memory bitmap
            var barcodeBitmap = (Bitmap)Image.FromFile(@"C:\Users\NEEO\Pictures\Barcode\6.jpg");

            // decode the barcode from the in memory bitmap
            var barcodeResult = barcodeReader.Decode(barcodeBitmap);

            // output results to console
            Console.WriteLine($"Decoded barcode text: {barcodeResult?.Text}");
            Console.WriteLine($"Barcode format: {barcodeResult?.BarcodeFormat}");
            Console.ReadLine();
        }
    }
}
