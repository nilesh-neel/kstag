using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class LookupRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public void AllMeasure_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWMeasure);
            // Act
            //var result = unitUnderTest.AllMeasure();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllTopic_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWTopic);
            // Act
            //var result = unitUnderTest.AllTokpic();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllLocation_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWLocation);
            // Act
            //var result = unitUnderTest.AllLocation();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllThreshold_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWThreshold);
            // Act
            //var result = unitUnderTest.AllThreshold();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllFrequency_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWFrequency);
            // Act
            //var result = unitUnderTest.AllFrequency();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllTimeWindow_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWTimeWindow);
            // Act
            //var result = unitUnderTest.AllTimeWindow();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllOrganisation_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWOrganization);
            // Act
            //var result = unitUnderTest.AllOrganisation();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllOperationalArea_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWOperationalArea);
            // Act
            //var result = unitUnderTest.AllOperationalArea();

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
