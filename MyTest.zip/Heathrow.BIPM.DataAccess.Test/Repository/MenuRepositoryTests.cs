using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Data.Entity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class MenuRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public void GetAllMenu_StateUnderTest_ExpectedBehavior()
        {
            var mockSet = new Mock<DbSet<Menu>>();
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateMenuRepository();

            var testMenu = GetTestMenu();
            var result = menuDataLayer.Setup(x => x.VWMenu);
            // Act
            //var result = unitUnderTest.GetAllMenu();

            // Assert
            Assert.AreNotEqual(result, testMenu);
        }

        [TestMethod]
        public void GetReportDetails_StateUnderTest_ExpectedBehavior()
        {
            var mockSet = new Mock<DbSet<PowerBiReportDetails>>();
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateMenuRepository();
            string strUserId = "User1";

            var testMenu = GetTestMenu();
            var result = menuDataLayer.Setup(x => x.spFetchReportDetails(strUserId));
            // Act
            //var result = unitUnderTest.GetReportDetails(strUserId);

            // Assert
            Assert.AreNotEqual(testMenu, result);
        }

        private List<Menu> GetTestMenu()
        {
            var testMenu = new List<Menu>
            {
                new Menu()
                {
                    BusinessReportId = "1",
                    Description = "desc",
                    FavouritesDescription = "fdesc",
                    MenuId = 19,
                    OrderId = 1,
                    Organization = "org",
                    CssIcon = "ico",
                    IsReport = true,
                    OperationalReportId = "2",
                    ParentId = 1,
                    Tooltip = "sample"
                }
            };

            return testMenu;
        }
    }
}
