using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class RegistrationRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task Save_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateRegistrationRepository();
            Registration registration = new Registration()
            {
                BagLocation = new List<Lookup>() { },
                FirstName = "Jhon",
                LastName = "David",
                Email = "jhon@xy.com",
                SelectedLocation = 1,
                AccessReason = "test",
                SelectedOperationalArea = 0,
                SelectedOrganisation = 1
            };

            var result = dataLayer.Setup(x => x.spRegistrationRequest(
               registration.FirstName, registration.LastName, registration.SelectedLocation, registration.SelectedOperationalArea,
               registration.AccessReason, registration.SelectedOrganisation, registration.Email));
            // Act
            //var result = await unitUnderTest.Save(
            //    registration);

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
