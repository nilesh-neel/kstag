using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class ShareRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task FetchAudienceGroup_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateShareRepository();

            var result = dataLayer.Setup(x => x.spFetchUserGroups("lawrencemckensy@heathrow.com"));
            // Act
            //var result = await unitUnderTest.FetchAudienceGroup();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task FetchRecipients_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateShareRepository();
            int audienceGroupId = 10;

            var result = dataLayer.Setup(x => x.spFetchGroupRecipients(audienceGroupId));
            // Act
            //var result = await unitUnderTest.FetchRecipients(
            //    audienceGroupId);

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
