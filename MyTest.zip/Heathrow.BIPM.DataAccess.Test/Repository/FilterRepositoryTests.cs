using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class FilterRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task SaveFilter_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateFilterRepository();
            FilterEntity filterData = new FilterEntity
            {
                FilterId = 1,
                MenuId = 10,
                UserId = "user1",
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}"
            };

            var result = dataLayer.Setup(x => x.spSaveFilterDetail(filterData.UserId, filterData.MenuId, filterData.FilterText,
                    filterData.FilterId));
            // Act
            //var result = await unitUnderTest.SaveFilter(
            //    filterData);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task FilterByMenuId_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateFilterRepository();
            int menuId = 19;
            string userId = "1";

            var result = dataLayer.Setup(x => x.spGetFilterDetails(menuId, userId));
            // Act
            //var result = await unitUnderTest.FilterByMenuId(
            //    menuId,
            //    userId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task FilterConfiguration_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateFilterRepository();

            var result = dataLayer.Setup(x => x.VWBaggageSystem);
            // Act
            //var result = await unitUnderTest.FilterConfiguration();

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
