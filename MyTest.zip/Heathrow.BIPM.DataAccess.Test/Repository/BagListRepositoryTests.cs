using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class BagListRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task GetUserExistingBagTags_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateBagListRepository();
            string userEmailId = "lawrencemckensy@heathrow.com";

            var result = dataLayer.Setup(x => x.spFetchUserExistingBagtags(userEmailId));
            // Act
            //var result = await unitUnderTest.GetUserExistingBagTags(
            //    userEmailId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task RemoveBagTags_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateBagListRepository();
            string bagTags = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]";
            string userEmailId = "lawrencemckensy@heathrow.com";

            var result = dataLayer.Setup(x => x.spRemoveBagtags(bagTags, userEmailId));
            // Act
            //var result = await unitUnderTest.RemoveBagTags(
            //    bagTags,
            //    userEmailId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task SaveBagTags_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateBagListRepository();
            string bagTags = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]";
            string userEmailId = "lawrencemckensy@heathrow.com";

            var result = dataLayer.Setup(x => x.spSaveBagtags(bagTags, userEmailId));
            // Act
            //var result = await unitUnderTest.SaveBagTags(
            //    bagTags,
            //    userEmailId);

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
