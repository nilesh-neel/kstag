using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class AssignHomePageRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task GetUserGroups_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAssignHomePageRepository();

            var testAssign = GetTestAssign();
            var result = dataLayer.Setup(x => x.spFetchUserGroups("lawrencemckensy@heathrow.com"));
            // Act
            //var result = await unitUnderTest.GetUserGroups();

            // Assert
            Assert.AreNotEqual(testAssign, result);
        }

        [TestMethod]
        public async Task GetGroupRecipients_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAssignHomePageRepository();
            int userGroupId = 19;

            var testAssign = GetTestAssign();
            var result = dataLayer.Setup(x => x.spFetchGroupRecipients(userGroupId));
            // Act
            //var result = await unitUnderTest.GetGroupRecipients(
            //    userGroupId);

            // Assert
            Assert.AreNotEqual(testAssign, result);
        }

        [TestMethod]
        public async Task SaveHomepage_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAssignHomePageRepository();
            string homepages = "HomePage1";

            var result = dataLayer.Setup(x => x.spSaveHomePage(homepages));
            // Act
            //var result = await unitUnderTest.SaveHomepage(
            //    homepages);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task FetchUserHomepage_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAssignHomePageRepository();
            string userEmailId = "HomePage2"; //TODO;

            var result = dataLayer.Setup(x => x.spFetchUserDashboard(userEmailId));
            // Act
            //var result = await unitUnderTest.FetchUserHomepage(
            //    userEmailId);

            // Assert
            Assert.IsNotNull(result);
        }

        private static List<AssignHomePage> GetTestAssign()
        {
            var testAssign = new List<AssignHomePage>
            {
                new AssignHomePage()
                {
                    Description = "Page description",
                    Homepage = "Homepage1",
                    UserEmail = "lawrencemckensy@heathrow.com",
                    UserFirstName = "Lawrence",
                    UserGroupId = 19,
                    UserId = 1
                }
            };

            return testAssign;
        }

    }
}
