using System;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.DataAccess.Interface;
using Unity;
using Unity.Injection;
using Unity.Lifetime;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class FavouritesRepositoryTests : BaseRepositoryTest
    {
        private FavouritesRepository _mockFavourites;

        [TestInitialize]
        public void TestInitialize()
        {
            var sut = new Mock<ObjectResult<int?>>();
            var result = SetupReturn(sut, 2).Object;

            var sut2 = new Mock<ObjectResult<spGetFavourites_Result>>();
            var result2 = SetupReturn(sut2, SpGetFavouritesResult().FirstOrDefault()).Object;


            RegisterResettableType<BaggageDbContext>(() => dbctx =>
            {
                dbctx.Setup(s => s.spSaveFavourites("gayathri.kannan@heathrow.com", 18)).Returns(result);
                dbctx.Setup(s => s.spGetFavourites("gayathri.kannan@heathrow.com")).Returns(result2);
            });
            RegisterResettableType<IFavourites>(() => mock =>
            {
                mock.Setup(s => s.GetUserFavourites("gayathri.kannan@heathrow.com")).Returns(GetTestFavourite());
            });
           // Container.RegisterType<DbContext, BaggageDbContext>(new PerResolveLifetimeManager(), new InjectionConstructor());
            Context = Container.Resolve<BaggageDbContext>();
            _mockFavourites = Container.Resolve<FavouritesRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {

        }
        //[TestMethod]
        //public async Task GetUserFavourites_ExpectedBehavior()
        //{
        //    mockFavourites.Setup(x => x.GetUserFavourites("gayathri.kannan@heathrow.com"))
        //        .Returns(GetTestFavourite());

        //    List<Favourites> testFavourite = await GetTestFavourite();
        //    var module = new FavouritesRepository(mockBaggageDbContext.Object);
        //    // Act
        //    IEnumerable<Favourites> result = await module.GetUserFavourites("gayathri.kannan@heathrow.com");
        //    // Assert
        //    Assert.AreEqual(testFavourite.GetEnumerator().Current, result.GetEnumerator().Current);
        //}


        [TestMethod]
        public async Task GetUserFavourites_StateUnderTest_ExpectedBehavior()
        {

            // Arrange

            var result = Context.spGetFavourites("gayathri.kannan@heathrow.com");
            //var unitUnderTest = this.CreateFavouritesRepository();
            var favourites = await _mockFavourites.GetUserFavourites("gayathri.kannan@heathrow.com");


            // Act
            //var result = await unitUnderTest.Save(
            //    favourites);

            // Assert
            // Assert.IsNotNull(result);
        }

        private static Task<List<Favourites>> GetTestFavourite()
        {
            List<Favourites> favouritesList = new List<Favourites>();
            var testFAvourite = new Favourites()
            {
                FavouriteId = 37,
                UserId = "gayathri.kannan@heathrow.com",
                FavouriteLink = new Menu
                {
                    MenuId = 21,
                    Description = "Baggage Status - Outbound",
                    IsReport = true,
                    OperationalReportId = "251b74f5-369c-41d2-85d5-6ea65ba1d3f3"
                }
            };
            favouritesList.Add(testFAvourite);
            return Task.FromResult(favouritesList);
        }

        private static List<spGetFavourites_Result> SpGetFavouritesResult()
        {
            List<spGetFavourites_Result> favouritesList = new List<spGetFavourites_Result>();
            var testFAvourite = new spGetFavourites_Result()
            {
                FavouriteId = 37,
                UserId = "gayathri.kannan@heathrow.com",
                Description = "Baggage Status - Outbound",
                MenuId = 21,
                IsReport = 1,
                ReportObjectId = "251b74f5-369c-41d2-85d5-6ea65ba1d3f3"
            };
            favouritesList.Add(testFAvourite);

            return favouritesList;
        }
    }
}
