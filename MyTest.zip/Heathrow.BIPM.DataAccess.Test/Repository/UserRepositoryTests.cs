using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class UserRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task UpdateOperationalAreaAndLocation_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateUserRepository();
            User objUser = new User
            {
                UserId = "1",
                OperationalArea = new Lookup() { RowId = 1 },
                Location = new Lookup() { RowId = 1 }
            };

            var result = dataLayer.Setup(x => x.spUpdateOperationAreaLocation(objUser.UserId,
                objUser.OperationalArea.RowId, objUser.Location.RowId));
            // Act
            //var result = await unitUnderTest.UpdateOperationalAreaAndLocation(
            //    objUser);

            // Assert
            Assert.IsNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     }

        [TestMethod]
        public void GetAllMenu_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateUserRepository();

            var result = dataLayer.Setup(x => x.VWMenu);
            // Act
            //var result = unitUnderTest.GetAllMenu();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task Fetch_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateUserRepository();
            string userId = "1";

            var result = dataLayer.Setup(x => x.spFetchUserDetails(userId));
            // Act
            //var result = await unitUnderTest.Fetch(
            //    userId);

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
