using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class PdfRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task GetPdfMenu_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreatePdfRepository();
            int menuId = 19; 

            var testPdf = GetTestPdf();
            var result = menuDataLayer.Setup(x => x.PdfMapping);
            // Act
            //var result = await unitUnderTest.GetPdfMenu(
            //    menuId);

            // Assert
            Assert.AreNotEqual(testPdf, result);
        }
        private static IList<PdfMappings> GetTestPdf()
        {
            var testPdf = new List<PdfMappings>
            {
                new PdfMappings()
                {
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    MenuId = 19,
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    PageNo = "4",
                    PdfId = 1,
                    PdfName = "sample.pdf"
                }
            };

            return testPdf;
        }
    }
}
