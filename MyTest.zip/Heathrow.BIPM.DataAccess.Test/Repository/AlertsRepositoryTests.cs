using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class AlertsRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }        

        [TestMethod]
        public async Task GetAlertNotification_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            string userId = "user1"; //""; //TODO;

            var testAlert = GetTodaysAlert();
            var result = menuDataLayer.Setup(x => x.spAlertNotification(userId));
            // Act
            //var result = await unitUnderTest.GetAlertNotification(
            //    userId);

            // Assert
            Assert.AreNotEqual(testAlert, result);
        }

        [TestMethod]
        public async Task GetTodaysAlert_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            string userId = "1";

            var testAlert = GetTodaysAlert();
            // Act
            var result = menuDataLayer.Setup(x => x.spTodaysAlert(userId));
            //var result = await unitUnderTest.GetTodaysAlert(
            //    userId);

            // Assert
            Assert.AreNotEqual(testAlert, result);
        }

        private static Task<IEnumerable<TodaysAlert>> GetTodaysAlert()
        {
            IEnumerable<TodaysAlert> testProducts = new List<TodaysAlert>()
            { new TodaysAlert
            {
                AlertId = 4,
                CreatedDate = DateTime.Now,
                ResponseType = 1,
                Title = "title",
                Topic = "test"
            } };

            return Task.FromResult(testProducts);
        }

        [TestMethod]
        public async Task GetMyAlertSettings_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            string emailId = "1";

            // Act
            var result = menuDataLayer.Setup(x => x.spFetchAlert(emailId,null));
            //var result = await unitUnderTest.GetMyAlertSettings(
            //    emailId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetAlertsById_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            string userId = "Admin"; 
            int alertId = 1; 

            var testAlert = GetTestAlert();
            // Act
            var result = menuDataLayer.Setup(x => x.spFetchAlert(userId, alertId));
            //var result = await unitUnderTest.GetAlertsById(
            //    userId,
            //    alertId);

            // Assert
            Assert.AreNotEqual(testAlert, result);
        }

        private static Alerts GetTestAlert()
        {
            var testAlert = new Alerts()
            {
                BagFrequency = new List<Lookup>() { },
                CreatedBy = "David",
                AlertId = 1,
            };

            return testAlert;
        }

        [TestMethod]
        public async Task GetTopicForMeasure_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            string selectedId = ""; //""; //TODO;

            var result = menuDataLayer.Setup(x => x.VWMeasure);
            // Act
            //var result = await unitUnderTest.GetTopicForMeasure(
            //    selectedId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetConfiguredAlert_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            string emailId = "1"; 

            var testAlert = GetTestAlertList();

            var result = menuDataLayer.Setup(x => x.spFetchConfiguredAlert(emailId, null));
            // Act
            //var result = await unitUnderTest.GetConfiguredAlert(
            //    emailId);

            // Assert
            Assert.AreNotEqual(testAlert, result);
        }

        private static IEnumerable<MyAlertSettings> GetTestAlertList()
        {
            IEnumerable<MyAlertSettings> testProducts = new List<MyAlertSettings>()
            { new MyAlertSettings
            {
                AlertId = 1,
                Description = "desc",

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                MandatoryOptional = 1,
                Measure = "1",

                Threshold = "1",
                ThresholdValue = "1",

                Title = "title",
                Topic = "test"
            } };

            return testProducts;
        }

        [TestMethod]
        public async Task GetConfiguredAlertById_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            string userId = "1"; //""; //TODO;
            int alertId = 0; //""; //TODO;

            var result = menuDataLayer.Setup(x => x.spFetchConfiguredAlert(userId, alertId));
            // Act
            //var result = await unitUnderTest.GetConfiguredAlertById(
            //    userId,
            //    alertId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task InsertUpdate_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            Alerts alert = new Alerts()
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                // SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title"

            };

            var testAlert = GetTestAlerts();
            var result = menuDataLayer.Setup(x => x.spInsertUpdateAlerts(""));
            // Act
            //var result = await unitUnderTest.InsertUpdate(
            //    alert);

            // Assert
            Assert.AreNotEqual(testAlert, result);
        }

        private static List<Alerts> GetTestAlerts()
        {
            var testProducts = new List<Alerts>();
            testProducts.Add(new Alerts
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                MandatoryOptional = 1,
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                ThresholdValue = "1",
                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 2,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //   SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 3,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //  SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 4,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,

                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //  SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });

            return testProducts;
        }
    }
}
