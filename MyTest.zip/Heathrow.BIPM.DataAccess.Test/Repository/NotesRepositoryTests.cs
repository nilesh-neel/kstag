using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class NotesRepositoryTests
    {
        private MockRepository mockRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task SaveNotes_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotesRepository();
            NotesEntity note = new NotesEntity
            {
                NotesId = 0,
                NoteDescription = "Notes Description added",
                UblValue = "12345",
                OrganizationId = 1,
                IsPublic = 1,
                CreatedDate = "12/24/2018",
                UserId = "Admin",
            };
            var testNotes = NotesList();

            var result = dataLayer.Setup(x => x.spSaveNotes(note.NotesId, note.NoteDescription, note.NotesValue,
                  Convert.ToBoolean(note.IsPublic), note.UserId, note.UblValue, note.NotesType));
            // Act
            //var result = await unitUnderTest.SaveNotes(
            //    note);

            // Assert
            Assert.AreNotEqual(testNotes, result);
        }

        [TestMethod]
        public async Task FetchNotes_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotesRepository();
            string notesValue = "Bt1";
            string notesType = "5673";
            string notesUblValue = "Fl1";
            string userId = "";

            var result = dataLayer.Setup(x => x.spFetchNotes(notesValue, notesUblValue, notesType, userId));
            // Act
            //var result = await unitUnderTest.FetchNotes(
            //    notesValue,
            //    notesType,
            //    notesUblValue,
            //    userId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task DeleteNotes_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotesRepository();
            int notesId = 15;
            string notesValue = "Bt1";
            string notesType = "B"; 
            string userId = "use@xy.com";

            var result = dataLayer.Setup(x => x.spDeleteNotes(notesId, userId, notesValue, notesType));
            // Act
            //var result = await unitUnderTest.DeleteNotes(
            //    notesId,
            //    notesValue,
            //    notesType,
            //    userId);

            // Assert
            Assert.IsNotNull(result);
        }

        private static Task<IList<NotesEntity>> NotesList(bool isDeleted = false)
        {
            IList<NotesEntity> notesList = new List<NotesEntity>
            {
                new NotesEntity
                {
                    NotesId = 5,
                    UblValue = "12345",
                    NoteDescription = "Flight is delayed",
                    OrganizationId=1,
                    IsPublic=1,
                    CreatedDate= "12/24/2018",
                    UserId="Admin",
                    UserFirstName="nilesh",
                }
            };
            return Task.FromResult(notesList);
        }
    }
}
