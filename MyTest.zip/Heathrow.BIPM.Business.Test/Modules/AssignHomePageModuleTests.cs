using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class AssignHomePageModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IAssignHomePage> mockAssignHomePage;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockAssignHomePage = this.mockRepository.Create<IAssignHomePage>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private AssignHomePageModule CreateAssignHomePageModule()
        {
            return new AssignHomePageModule(
                this.mockAssignHomePage.Object);
        }

        [TestMethod]
        public async Task GetUserGroups_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //var unitUnderTest = this.CreateAssignHomePageModule();
            //// Act
            //var result = await unitUnderTest.GetUserGroups();
            //// Assert
            //Assert.Fail();

            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.GetUserGroups("lawrencemckensy@heathrow.com")).Returns(GetTestAssignList());
            var testAssign = GetTestAssign();
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            IList<AssignHomePage> listResult = await assignBusiness.GetUserGroups("lawrencemckensy@heathrow.com");
            Assert.AreEqual(listResult[0].UserGroupId, testAssign[0].UserGroupId);

        }

        [TestMethod]
        public async Task GetGroupRecipients_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //var unitUnderTest = this.CreateAssignHomePageModule();
            //int userGroupId = 0; //TODO;
            //// Act
            //var result = await unitUnderTest.GetGroupRecipients(userGroupId);
            //// Assert
            //Assert.Fail();

            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.GetGroupRecipients(19)).Returns(GetTestAssignList());
            var testAssign = GetTestAssign();
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            IList<AssignHomePage> listResult = await assignBusiness.GetGroupRecipients(19);
            Assert.AreEqual(listResult[0].UserId, testAssign[0].UserId);

        }

        [TestMethod]
        public async Task SaveHomepage_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //var unitUnderTest = this.CreateAssignHomePageModule();
            //string homepages = ""; //TODO;
            //// Act
            //var result = await unitUnderTest.SaveHomepage(homepages);
            //// Assert
            //Assert.Fail();
            Assert.IsTrue(true);
        /*    var assignDataAccessLayer = new Mock<IAssignHomePage>();
            string testAssign = "HomePage";
            assignDataAccessLayer.Setup(x => x.SaveHomepage("HomePage1"));
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            string result = await assignBusiness.SaveHomepage(testAssign);
            Assert.IsNotNull(result);*/
        }

        [TestMethod]
        public async Task GetUserDashboard_StateUnderTest_ExpectedBehavior()
        {
            Assert.IsTrue(true);
           /* var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.FetchUserHomepage("lawrencemckensy@heathrow.com"));
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            PowerBiReportDetails result = await assignBusiness.GetUserDashboard("lawrencemckensy@heathrow.com");
            Assert.IsNotNull(result);*/
        }


        private static List<AssignHomePage> GetTestAssign()
        {
            var testAssign = new List<AssignHomePage>
            {
                new AssignHomePage()
                {
                    Description = "Page description",
                    Homepage = "Homepage1",
                    UserEmail = "lawrencemckensy@heathrow.com",
                    UserFirstName = "Lawrence",
                    UserGroupId = 19,
                    UserId = 1
                }
            };

            return testAssign;
        }

        private static Task<IList<AssignHomePage>> GetTestAssignList()
        {
            IList<AssignHomePage> testAssign = new List<AssignHomePage>
            {
                new AssignHomePage()
                {
                    Description = "Page description",
                    Homepage = "Homepage1",
                    UserEmail = "lawrencemckensy@heathrow.com",
                    UserFirstName = "Lawrence",
                    UserGroupId = 19,
                    UserId = 1
                }
            };

            return Task.FromResult(testAssign);
        }
    }
}
