using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class PowerBIModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IMenuModule> mockMenuModule;
        private Mock<IAssignHomePage> mockAssignHomePage;
        private Mock<IFilterModule> mockFilterModule;
        private Mock<IAssignHomePageModule> mockAssignHomePageModule;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockMenuModule = this.mockRepository.Create<IMenuModule>();
            this.mockAssignHomePage = this.mockRepository.Create<IAssignHomePage>();
            this.mockFilterModule = this.mockRepository.Create<IFilterModule>();
            this.mockAssignHomePageModule = this.mockRepository.Create<IAssignHomePageModule>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private PowerBIModule CreatePowerBIModule()
        {
            return new PowerBIModule(
                this.mockMenuModule.Object,
                this.mockAssignHomePage.Object,
                this.mockFilterModule.Object,
                this.mockAssignHomePageModule.Object);
        }

        [TestMethod]
        public async Task EmbedReportV1_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //var unitUnderTest = this.CreatePowerBIModule();
            //string userName = ""; //TODO;
            //string roles = ""; //TODO;
            //int menuId = 0; //TODO;

            //// Act
            //var result = await unitUnderTest.EmbedReportV1(
            //    userName,
            //    roles,
            //    menuId);

            // Assert
            Assert.IsTrue(true);
        }

        [TestMethod]
        public async Task EmbedReportV2_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //var unitUnderTest = this.CreatePowerBIModule();
            //int menuId = 0; //TODO;
            //int reportType = 0; //TODO;

            //// Act
            //var result = await unitUnderTest.EmbedReportV2(
            //    menuId,
            //    reportType);

            // Assert
            Assert.IsTrue(true);
        }

        [TestMethod]
        public async Task GetDashboardInGroup_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //var unitUnderTest = this.CreatePowerBIModule();

            //// Act
            //var result = await unitUnderTest.GetDashboardInGroup();

            // Assert
            Assert.IsTrue(true);
        }
    }
}
