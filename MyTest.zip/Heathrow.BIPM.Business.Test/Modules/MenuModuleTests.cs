using System;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Globalization;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class MenuModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IMenu> mockMenu;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockMenu = this.mockRepository.Create<IMenu>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private MenuModule CreateMenuModule()
        {
            return new MenuModule(
                this.mockMenu.Object);
        }

        [TestMethod]
        public void GetAllMenu_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateMenuModule();
            var menuBusinessLayer = new Mock<IMenu>();

            var testMenu = GetTestMenu();

            var result = menuBusinessLayer.Setup(x => x.GetAllMenu())
                .Returns(GetTestMenu());
            // Act
            //var result = unitUnderTest.GetAllMenu();

            // Assert
            Assert.AreNotEqual(result, testMenu);
        }
/*
        [TestMethod]
        public void GetUserReports_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateMenuModule();
            string strUserId = "nilesh.more@heathrow.com";

            var testMenu = PbiReportDetails();
            // Act
            var result = unitUnderTest.GetUserReports(
                strUserId);

            // Assert
            Assert.AreEqual(result.GetEnumerator().Current, testMenu.GetEnumerator().Current);
        }
        */
        private List<Menu> GetTestMenu()
        {
            var testMenu = new List<Menu>
            {
                new Menu()
                {
                    BusinessReportId = "1",
                    Description = "desc",
                    FavouritesDescription = "fdesc",
                    MenuId = 19,
                    OrderId = 1,
                    Organization = "org",
                    CssIcon = "ico",
                    IsReport = true,
                    OperationalReportId = "2",
                    ParentId = 1,
                    Tooltip = "sample"
                }
            };

            return testMenu;
        }

        private List<PowerBiReportDetails> PbiReportDetails()
        {
            List<PowerBiReportDetails> pbiList = new List<PowerBiReportDetails>
            {
                new PowerBiReportDetails
                {
                    MenuId = 18,
                    FilterType = "1",
                    //sReport = true,
                    ReportId = "08414021-b1dd-4da4-9322-ad256f2abd3d",
                    ReportSection = "ReportSectionc426823d236c1c717a74",
                    ReportType = Convert.ToInt32("1", CultureInfo.InvariantCulture),
                    WorkSpaceId = "9267fd29-3222-4dfc-9680-902f44dbda89",
                    PbiRoles = "pbi"
                }
            };
            return pbiList;
        }
    }
}
