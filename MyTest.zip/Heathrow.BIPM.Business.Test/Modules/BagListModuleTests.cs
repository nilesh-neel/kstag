using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class BagListModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IBagList> mockBagList;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBagList = this.mockRepository.Create<IBagList>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private BagListModule CreateBagListModule()
        {
            return new BagListModule(
                this.mockBagList.Object);
        }

        [TestMethod]
        public async Task GetUserExistingbagtags_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //var unitUnderTest = this.CreateBagListModule();
            //string userEmailId = ""; //TODO;

            //// Act
            //var result = await unitUnderTest.GetUserExistingbagtags(
            //    userEmailId);

            //// Assert
            //Assert.Fail();

            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.GetUserExistingBagTags("lawrencemckensy@heathrow.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            //var testBagList = TestBagListCollection();
            string result = await bagListBusiness.GetUserExistingbagtags("lawrencemckensy@heathrow.com");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task RemoveBagTags_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //var unitUnderTest = this.CreateBagListModule();
            //string bagTags = ""; //TODO;
            //string userEmailId = ""; //TODO;
            //// Act
            //var result = await unitUnderTest.RemoveBagTags(
            //    bagTags,
            //    userEmailId);
            //// Assert
            //Assert.Fail();
            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.RemoveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "lawrencemckensy@heathrow.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            string result = await bagListBusiness.RemoveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "lawrencemckensy@heathrow.com");
            Assert.IsNotNull(result);

        }

        [TestMethod]
        public async Task SaveBagTags_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //var unitUnderTest = this.CreateBagListModule();
            //string bagTags = ""; //TODO;
            //string userEmailId = ""; //TODO;
            //// Act
            //var result = await unitUnderTest.SaveBagTags(
            //    bagTags,
            //    userEmailId);
            //// Assert
            //Assert.Fail();
            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.SaveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "lawrencemckensy@heathrow.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            string result = await bagListBusiness.SaveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "lawrencemckensy@heathrow.com");
            Assert.IsNotNull(result);

        }

        private static BagList TestBagListCollection()
        {
            return new BagList()
            {
                BagTagsJson = "[{'TableName':'dummyBagItem','ColumnName':'dummyTagNumber','ColumnValue':['3589177579,3589219538']}]",
                UserId = 2,
                BagListId = 4,
                BagTags = "3589219568",
                OtherUserId = 3,
                UpdatedDate = DateTime.Now,
                UserEmail = "lawrencemckensy@heathrow.com",
                UserFirstName = "Lawrence",
                UserLastName = "Mckensy",
                UserOrg = "TestCompany",
                UserRole = "Admin",
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static Task<string> ExistingBagtags()
        {
            return Task.FromResult("[{'TableName':'dummyBagItem','ColumnName':'dummyTagNumber','ColumnValue':['3589177579,3589219538']}]");
        }
    }
}
