using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class RegistrationModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IRegistration> mockRegistration;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockRegistration = this.mockRepository.Create<IRegistration>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private RegistrationModule CreateRegistrationModule()
        {
            return new RegistrationModule(
                this.mockRegistration.Object);
        }

        [TestMethod]
        public async Task Save_StateUnderTest_ExpectedBehavior()
        {
            Mock<IRegistration> dataAccessLayer = new Mock<IRegistration>();
            // Arrange
            //var unitUnderTest = this.CreateRegistrationModule();
            Registration registration = new Registration()
            {
                BagLocation = new List<Lookup>() { },
                FirstName = "Jhon",
                LastName = "David",
                Email = "jhon@xy.com",
                SelectedLocation = 1,
                AccessReason = "test",
                SelectedOperationalArea = 0,
                SelectedOrganisation = 1
            };

            var result = dataAccessLayer.Setup(x => x.Save(registration));

            //// Act
            //var result = await unitUnderTest.Save(
            //    registration);

            // Assert
            Assert.IsNotNull(result);
        }

        private static Registration GetTestRegistration()
        {
            var testRegistration = new Registration()
            {
                BagLocation = new List<Lookup>() { },
                FirstName = "Jhon",
                LastName = "David",
                Email = "jhon@xy.com",
                SelectedLocation = 1,
                AccessReason = "test",
                SelectedOperationalArea = 0,

            };

            return testRegistration;
        }
    }
}
