using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class LookupModuleTests
    {
        private MockRepository mockRepository;

        private Mock<ILookup> mockLookup;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockLookup = this.mockRepository.Create<ILookup>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private LookupModule CreateLookupModule()
        {
            return new LookupModule(
                this.mockLookup.Object);
        }

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
           // var unitUnderTest = this.CreateLookupModule();

            // Act

            // Assert
            Assert.IsTrue(true);
        }
        [TestMethod]
        public void LookupModuleBagFrequencyList_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<ILookup>();         
            mockAlerts.Setup(x => x.AllFrequency())
        .Returns(GetTestLookUp());

            var test = GetTestLookUp();
            var module = new LookupModule(mockAlerts.Object);
            // Act
            var result = module.BagFrequencyList;
            // Assert
            Assert.AreEqual(test.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public void LookupModuleBagLocationList_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<ILookup>();
            mockAlerts.Setup(x => x.AllLocation())
        .Returns(GetTestLookUp());

            var test = GetTestLookUp();
            var module = new LookupModule(mockAlerts.Object);
            // Act
            var result = module.BagLocationList;
            // Assert
            Assert.AreEqual(test.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public void LookupModuleBagMeasureList_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<ILookup>();
            //var unitUnderTest = this.CreateAlertsModule();
            mockAlerts.Setup(x => x.AllMeasure())
        .Returns(GetTestLookUp());

            var test = GetTestLookUp();
            var module = new LookupModule(mockAlerts.Object);
            // Act
            var result = module.BagMeasureList;
            // Assert
            Assert.AreEqual(test.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public void LookupModuleBagOperationalAreaList_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<ILookup>();
            mockAlerts.Setup(x => x.AllOperationalArea())
        .Returns(GetTestLookUp());

            var test = GetTestLookUp();
            var module = new LookupModule(mockAlerts.Object);
            // Act
            var result = module.BagOperationalAreaList;
            // Assert
            Assert.AreEqual(test.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public void LookupModuleBagOrganisationList_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<ILookup>();
            //var unitUnderTest = this.CreateAlertsModule();
            mockAlerts.Setup(x => x.AllOrganisation())
        .Returns(GetTestLookUp());

            var test = GetTestLookUp();
            var module = new LookupModule(mockAlerts.Object);
            // Act
            var result = module.BagOrganisationList;
            // Assert
            Assert.AreEqual(test.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public void LookupModuleBagThresholdList_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<ILookup>();
            //var unitUnderTest = this.CreateAlertsModule();
            mockAlerts.Setup(x => x.AllThreshold())
        .Returns(GetTestLookUp());

            var test = GetTestLookUp();
            var module = new LookupModule(mockAlerts.Object);
            // Act
            var result = module.BagThresholdList;
            // Assert
            Assert.AreEqual(test.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public void LookupModuleBagTimeWindowList_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<ILookup>();
            //var unitUnderTest = this.CreateAlertsModule();
            mockAlerts.Setup(x => x.AllTimeWindow())
        .Returns(GetTestLookUp());

            var test = GetTestLookUp();
            var module = new LookupModule(mockAlerts.Object);
            // Act
            var result = module.BagTimeWindowList;
            // Assert
            Assert.AreEqual(test.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public void LookupModuleBagTopicList_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<ILookup>();
            //var unitUnderTest = this.CreateAlertsModule();
            mockAlerts.Setup(x => x.AllTopic())
        .Returns(GetTestLookUp());

            var test = GetTestLookUp();
            var module = new LookupModule(mockAlerts.Object);
            // Act
            var result = module.BagTopicList;
            // Assert
            Assert.AreEqual(test.GetEnumerator().Current, result.GetEnumerator().Current);
        }


        public IEnumerable<Lookup> GetTestLookUp()
        {
            IEnumerable<Lookup> testProducts = new List<Lookup>()
            { new Lookup
            {
                LookupTypeName="LookupName",
                RowId=1,
                Selected=1
            } };

            return testProducts;
        }


     

    }
}
