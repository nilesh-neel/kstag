using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class SearchModuleTests
    {
        private MockRepository mockRepository;

        private Mock<ISearch> mockSearch;
        private Mock<IBpmPowerBi> mockBpmPowerBi;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockSearch = this.mockRepository.Create<ISearch>();
            this.mockBpmPowerBi = this.mockRepository.Create<IBpmPowerBi>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private SearchModule CreateSearchModule()
        {
            return new SearchModule(this.mockSearch.Object, this.mockBpmPowerBi.Object);
        }

        [TestMethod]
        public async Task SearchData_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //var unitUnderTest = this.CreateSearchModule();
            //string searchQuery = ""; //TODO;
            //string searchPrefix = ""; //TODO;

            //// Act
            //var result = await unitUnderTest.SearchData(
            //    searchQuery,
            //    searchPrefix);

            // Assert
            Assert.IsTrue(true);
        }
    }
}
