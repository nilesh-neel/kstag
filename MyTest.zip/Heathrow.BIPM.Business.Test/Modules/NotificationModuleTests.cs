using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class NotificationModuleTests
    {
        private MockRepository mockRepository;

        private Mock<INotification> mockNotification;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockNotification = this.mockRepository.Create<INotification>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private NotificationModule CreateNotificationModule()
        {
            return new NotificationModule(
                this.mockNotification.Object);
        }

        [TestMethod]
        public async Task GetNotificationById_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockNotification = new Mock<INotification>();
            mockNotification.Setup(x => x.GetNotificationByNotificationId("1", 1))
        .Returns(GetTestNotification());

            var testNotification = await GetTestNotification();
            var module = new NotificationModule(mockNotification.Object);
            // Act
            var result = await module.GetNotificationById("1", 1);
            // Assert
            Assert.AreEqual(testNotification.NotificationId, result.NotificationId);
        }
        [TestMethod]
        public async Task GetNotificationById_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockNotification = new Mock<INotification>();
            mockNotification.Setup(x => x.GetNotificationByNotificationId("1", 1))
        .Returns(GetTestNotification());

            var testNotification = await GetTestNotification();
            var module = new NotificationModule(mockNotification.Object);
            // Act
            var result = await module.GetNotificationById(null, 1);
            // Assert
            Assert.AreEqual(null, result);
        }

        [TestMethod]
        public async Task GetUsersNotification_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockNotification = new Mock<INotification>();
            mockNotification.Setup(x => x.GetUserNotification("user1"))
        .Returns(GetTestNotificationList());
            var testNotification = await GetTestNotificationList();
            var module = new NotificationModule(mockNotification.Object);
            // Act
            var result = await module.GetUsersNotification("user1");

            // Assert
            Assert.AreEqual(testNotification.GetEnumerator().Current, result.GetEnumerator().Current);
        }

        [TestMethod]
        public async Task GetUsersNotification_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockNotification = new Mock<INotification>();
            mockNotification.Setup(x => x.GetUserNotification("user1"))
        .Returns(GetTestNotificationList());      
            var module = new NotificationModule(mockNotification.Object);
            // Act
            var result = await module.GetUsersNotification(null);

            // Assert
            Assert.AreEqual(null, result);
        }

        [TestMethod]
        public async Task InsertUpdate_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockNotification = new Mock<INotification>();
            mockNotification.Setup(p => p.InsertUpdate(
                new Notification()
                {
                    NotificationId = 1,
                    Description = "desc",
                    BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    DateAndTime = DateTime.Now,
                    DisableNotification = false,
                    EndDate = DateTime.Now,
                    IsEmail = false,
                    IsMobile = true,
                    IsOnScreen = true,
                    IsSubscribe = false,
                    Location = "1",
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    OperationalArea = "1",
                    Organisation = "1",
                    ResponseType = 1,
                    SelectedMeasure = 1,
                    SelectedOrganisation = 1,
                    SelectedThreshold = 1,
                    SelectedTimeWindow = 1,
                    SelectedTopic = 1,
                    StartDate = DateTime.Now,
                    Topic = "test"

                }));
            NotificationModule module = new NotificationModule(mockNotification.Object);
            // Act
            var result1 = await module.InsertUpdate(new Notification()
            {
                NotificationId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableNotification = false,
                EndDate = DateTime.Now,
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                OperationalArea = "1",
                Organisation = "1",
                ResponseType = 1,
                SelectedMeasure = 1,
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                Topic = "test"

            });
            // Assert
            Assert.AreNotEqual("Save Success", result1);
        }

        [TestMethod]
        public async Task GetScrollingNotification_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockNotification = new Mock<INotification>();
            mockNotification.Setup(x => x.GetScrollingNotification("user1"))
        .Returns(GetTestNotificationList());
            var testNotification = await GetTestNotificationList();
            var module = new NotificationModule(mockNotification.Object);
            // Act
            var result = await module.GetScrollingNotification("user1");

            // Assert
            Assert.AreEqual(testNotification.GetEnumerator().Current, result.GetEnumerator().Current);
        }

        [TestMethod]
        public async Task GetScrollingNotification_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockNotification = new Mock<INotification>();
               mockNotification.Setup(x => x.GetScrollingNotification("user1"))
             .Returns(GetTestNotificationList()); 
            var module = new NotificationModule(mockNotification.Object);
            //var rep = await mockNotification.Object.GetUserNotification("gayathri.kannan@heathrow.com");
            // Act
            var result = await module.GetScrollingNotification(null);

            // Assert
            Assert.AreEqual(null, result);
        }
        private static Task<Notification> GetTestNotification()
        {
            var testNotification = new Notification()
            {
                CreatedBy = "David",
                NotificationId = 1,
            };

            return Task.FromResult(testNotification);
        }

        private static Task<IEnumerable<Notification>> GetTestNotificationList()
        {
            IEnumerable<Notification> testProducts = new List<Notification>()
            { new Notification
            {
                NotificationId = 1,
                Description = "desc",

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Topic = "test"
            } };

            return Task.FromResult(testProducts);
        }
    }
}
