using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Web.Test.Entity
{
    [TestClass]
    public class MenuEntityTests
    {
        private MockRepository mockRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private Menu CreateMenu()
        {
            return GetTestMenu();
        }

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
            var unitUnderTest = this.CreateMenu();

            // Act
            Assert.IsNotNull(unitUnderTest);
            // Assert
           // Assert.Fail();
        }

        private static Menu GetTestMenu()
        {

            var testMenu = new Menu()
            {
                BusinessReportId = "1",
                Description = "desc",
                FavouritesDescription = "fdesc",
                MenuId = 19,
                OrderId = 1,
                Organization = "org",
                CssIcon = "ico",
                IsReport = true,
                OperationalReportId = "2",
                ParentId = 1,
                Tooltip = "sample"
            };

            return testMenu;
        }
    }
}
