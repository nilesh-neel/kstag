using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;

namespace Heathrow.BIPM.Web.Test.Entity
{
    [TestClass]
    public class FilterEntityTests
    {
        private MockRepository mockRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private FilterEntity CreateFilterEntity()
        {
            return TestFilterCollection();
        }
        private FilterControlEntity CreateControlFilterEntity()
        {
            return TestFilterControl();
        }

        [TestMethod]
        public void TestFilterEntity()
        {
            // Arrange
            var unitUnderTest = this.CreateFilterEntity();

            // Assert
            Assert.IsNotNull(unitUnderTest);

        }
        [TestMethod]
        public void TestFilterControlEntity()
        {
            // Arrange
            var unitUnderTest = this.CreateControlFilterEntity();

            // Assert
            Assert.IsNotNull(unitUnderTest);

        }

        private static FilterEntity TestFilterCollection()
        {
            var collection = new FilterEntity
            {
                FilterId = 10,
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}",
                MenuId = 19,
                UserId = "Admin",
            };

            var pbiList = new List<string> { "0000103439", "0000103438" };

            var filterselection = new FilterSelection();
            filterselection.ColumnName = "TagNumber";
            filterselection.ControlMappingId = 5;
            filterselection.Operator = "In";
            filterselection.TableName = "BagItem";
            ((List<string>)filterselection.ColumnValue).AddRange(pbiList);
            collection.PBIMappingList.Add(filterselection);
            collection.FilterItemSelection.Add(filterselection);

            return collection;
        }

        private static FilterControlEntity TestFilterControl()
        {
            var collection = new FilterControlEntity();
            collection.BaggageSystemList.Add(new DropDownFilter { Value = "10" });
            collection.NotLoadedCategoryList.Add(new NotLoadedDropDown { Value = "1", Label = "RIS" , CategoryId = 1 });
            collection.NotLoadedSubCategoryList.Add(new NotLoadedDropDown { Value = "1", Label = "Late arrival", CategoryId = 1 });
            collection.OutboundAircraftList.Add(new DropDownFilter { Value = "All" });
            collection.OutboundAirlineList.Add(new DropDownFilter { Value = "BA2304" });
            collection.OutboundHandlerList.Add(new DropDownFilter { Value = "None" });
            collection.OutboundTerminalList.Add(new DropDownFilter { Value = "T2" });
            collection.LastSeenLocationList.Add(new DropDownFilter { Value = "All" });
            collection.DestinationList.Add(new DropDownFilter { Value = "0A1" });
            return collection;
        }
    }
}
