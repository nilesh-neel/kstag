﻿using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class RegistrationTest
    {
        
        [TestMethod]
        public async Task Post_ShouldNotReturnRegistrationValues()
        {
            var RegisterBusinessLayer = new Mock<IRegistrationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            RegisterBusinessLayer.Setup(x => x.Save(GetTestRegistration()));

            var data = GetTestRegistration();

            var controller = new RegistrationController(RegisterBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = await controller.Post(data);

            Assert.IsNull(result);
        }
        [TestMethod]
        public async Task Post_ShouldReturnRegistrationValues()
        {
            var RegisterBusinessLayer = new Mock<IRegistrationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            RegisterBusinessLayer.Setup(x => x.Save(GetTestRegistration()))
                .Returns(Task.FromResult("Success"));

            var data = GetTestRegistration();

            RegistrationController controller = new RegistrationController(RegisterBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = await controller.Post(data);

            Assert.IsTrue(true);

        }


        [TestMethod]
        public void Get_ShouldNotReturnRegistrationValues()
        {
            var RegisterBusinessLayer = new Mock<IRegistrationModule>();

            var lookBusinessLayer = new Mock<ILookupModule>();

            lookBusinessLayer.Setup(s => s.BagMeasureList).Returns(() => new List<Lookup>() { new Lookup { LookupTypeName = "test", RowId = 1, Selected = 1 } });

            var testAlert = GetTestRegistration();
            var controller = new RegistrationController(RegisterBusinessLayer.Object, lookBusinessLayer.Object);

            var result = controller.Get();
            Assert.AreNotEqual(testAlert, result);
        }

        private static Registration GetTestRegistration()
        {
            var testRegistration = new Registration()
            {
                BagLocation = new List<Lookup>() { },
                FirstName = "Jhon",
                LastName = "David",
                Email = "jhon@xy.com",
                SelectedLocation = 1,
                AccessReason = "test",
                SelectedOperationalArea = 0,

            };

            return testRegistration;
        }
    }
}
