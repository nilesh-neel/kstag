﻿using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class FilterTest
    {
        [TestMethod]
        [Description("Filter selection values are retrieved based on menuID if the value is exist in the table")]
        public async Task GetFilterByMenuID_ShouldReturnFilterValues()
        {
            var filterBusinessLayer = new Mock<IFilterModule>();

            filterBusinessLayer.Setup(x => x.FilterByMenuId(19, string.Empty))
                    .Returns(Task.FromResult(TestFilterCollection()));
            var controller = new FilterController(filterBusinessLayer.Object);

            FilterEntity testFilter = TestFilterCollection();
            var actionResult = await controller.Get(19);

            Assert.AreEqual(((OkNegotiatedContentResult<FilterEntity>)actionResult).Content.FilterItemSelection.Count, testFilter.FilterItemSelection.Count);
        }

        [TestMethod]
        [Description("Return not found result the given menu id is not exist in the table")]
        public async Task GetFilterByMenuID_ShouldReturnNotFilterValues()
        {
            var filterBusinessLayer = new Mock<IFilterModule>();

            filterBusinessLayer.Setup(x => x.FilterByMenuId(100, ""))
                .Returns(Task.FromResult(
                 new FilterEntity()
                ));

            FilterEntity testFilter = TestFilterCollection();

            FilterController controller = new FilterController(filterBusinessLayer.Object);

            IHttpActionResult actionResult = await controller.Get(100);
            Assert.AreNotEqual(((OkNegotiatedContentResult<FilterEntity>)actionResult).Content.FilterItemSelection, testFilter.FilterItemSelection);
        }

        [TestMethod]
        [Description("Filter values are saved in the table and return saved filter id")]
        public async Task PostFilter_ShouldReturnSameFilter()
        {
            var filterBusinessLayer = new Mock<IFilterModule>();

            filterBusinessLayer.Setup(x => x.SaveFilter(
                 new FilterEntity
                 {
                     FilterId = 1,
                     MenuId = 10,
                     UserId = "user1",
                     FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}"
                 }
                ));

            FilterEntity data = new FilterEntity
            {
                FilterId = 0,
                MenuId = 10,
                UserId = "user1",
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:0000103438]}"
            };

            FilterController controller = new FilterController(filterBusinessLayer.Object);

            var result = await controller.Post(data);

            Assert.IsNotNull(result);
            Assert.AreEqual(((OkNegotiatedContentResult<int>)result).Content, data.FilterId);
        }


        [TestMethod]
        [Description("Filter values are not saved in the table and not return filter id")]
        public async Task PostFilter_ShouldNotReturnSameFilter()
        {
            var filterBusinessLayer = new Mock<IFilterModule>();

            filterBusinessLayer.Setup(x => x.SaveFilter(
                new FilterEntity
                {
                    FilterId = 1,
                    MenuId = 10,
                    UserId = "user1",
                    FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}"
                }
            ));

            FilterEntity data = new FilterEntity
            {
                MenuId = 10,
                UserId = "user1",
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:0000103438]}"
            };

            FilterController controller = new FilterController(filterBusinessLayer.Object);

            var result = await controller.Post(data);

            Assert.IsNotNull(result);
            Assert.AreNotEqual(((OkNegotiatedContentResult<int>)result).Content, data);
        }

        [TestMethod]
        [Description("Filter configuration values are retrieved if the value is exist in the table")]
        public async Task GetFilterConfiguration_ShouldReturnFilterValues()
        {
            var filterBusinessLayer = new Mock<IFilterModule>();

            filterBusinessLayer.Setup(x => x.FilterConfiguration())
                    .Returns(Task.FromResult(TestFilterControl()));
            var controller = new FilterController(filterBusinessLayer.Object);

            FilterControlEntity testFilter = TestFilterControl();
            var actionResult = await controller.Get();

            Assert.AreEqual(((OkNegotiatedContentResult<FilterControlEntity>)actionResult).Content.BaggageSystemList.Count, testFilter.BaggageSystemList.Count);
        }

        [TestMethod]
        [Description("Filter configuration values are retrieved if the value is exist in the table")]
        public async Task GetFilterConfiguration_ShouldNotReturnFilterValues()
        {
            var filterBusinessLayer = new Mock<IFilterModule>();

            filterBusinessLayer.Setup(x => x.FilterConfiguration())
                    .Returns(Task.FromResult(new FilterControlEntity()));

            var controller = new FilterController(filterBusinessLayer.Object);

            FilterControlEntity testFilter = TestFilterControl();
            var actionResult = await controller.Get();

            Assert.AreNotEqual(((OkNegotiatedContentResult<FilterControlEntity>)actionResult).Content, testFilter);
        }

        /// <summary>
        /// Get Mocked filter collection values
        /// </summary>
        /// <returns></returns>
        private static FilterEntity TestFilterCollection()
        {
            var collection = new FilterEntity
            {
                FilterId = 10,
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}",
                MenuId = 19,
                UserId = "Admin",
            };
            
            var pbiList = new List<string> { "0000103439", "0000103438" };

            var filterselection = new FilterSelection();
            filterselection.ColumnName = "TagNumber";
            filterselection.ControlMappingId = 5;
            filterselection.Operator = "In";
            filterselection.TableName = "BagItem";
            ((List<string>)filterselection.ColumnValue).AddRange(pbiList);
            collection.PBIMappingList.Add(filterselection);
            collection.FilterItemSelection.Add(filterselection);
            return collection;

        }

        private static FilterControlEntity TestFilterControl()
        {
            var collection = new FilterControlEntity();

            collection.BaggageSystemList.Add(new DropDownFilter { Value = "10" });
            collection.NotLoadedCategoryList.Add(new NotLoadedDropDown { Value = "1", Label = "RIS" });
            collection.NotLoadedSubCategoryList.Add(new NotLoadedDropDown { Value = "1", Label = "Late arrival" });
            collection.OutboundAircraftList.Add(new DropDownFilter { Value = "All" });
            collection.OutboundAirlineList.Add(new DropDownFilter { Value = "BA2304" });
            collection.OutboundHandlerList.Add(new DropDownFilter { Value = "None" });
            collection.OutboundTerminalList.Add(new DropDownFilter { Value = "T2" });
            collection.LastSeenLocationList.Add(new DropDownFilter { Value = "All" });
            collection.DestinationList.Add(new DropDownFilter { Value = "0A1" });

            return collection;
        }

    }
}
