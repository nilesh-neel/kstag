﻿using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Results;
using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Test;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Unity;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class MenuTest : BaseTest
    {
        [TestInitialize]
        public void TestSetup()
        {
            // setup the IMenuModule for all tests
            RegisterResettableType<IMenuModule>(() => mock =>
            {
                mock.Setup(s => s.GetAllMenu())
                    .Returns(GetTestMenu());
            });
        }


        [TestMethod]
        public void Get_ShouldReturnMenuList()
        {
            var testMenu = GetTestMenu();
            var controller = Container.Resolve<MenuController>();
            IHttpActionResult response = controller.Get();
            var result = (List<Menu>)(((OkNegotiatedContentResult<IEnumerable<Menu>>)response).Content);
            Assert.AreEqual(result.Count, testMenu.Count);
        }

        private List<Menu> GetTestMenu()
        {
            var testMenu = new List<Menu>
            {
                new Menu()
                {
                    BusinessReportId = "1",
                    Description = "desc",
                    FavouritesDescription = "fdesc",
                    MenuId = 19,
                    OrderId = 1,
                    Organization = "org",
                    CssIcon = "ico",
                    IsReport = true,
                    OperationalReportId = "2",
                    ParentId = 1,
                    Tooltip = "sample"
                }
            };

            return testMenu;
        }
    }
}
