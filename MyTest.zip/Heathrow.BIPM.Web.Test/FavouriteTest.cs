﻿using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Results;
using Heathrow.BIPM.Web.Test;
using Unity;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class FavouriteTest : BaseTest
    {
        private FavoritesController _controller;

        [TestInitialize]
        public void TestSetup()
        {
            // setup the IMenuModule for all tests
            RegisterResettableType<IFavouriteModule>(() => mock =>
            {
                mock.Setup(s => s.GetUserFavourites("nilesh.more@heathrow.com"))
                    .Returns(Task.FromResult(GetTestFavourites().AsEnumerable()));
                mock.Setup(x => x.Save(GetTestFavourites()[0]))
                    .Returns(Task.FromResult(GetTestFavourites().AsEnumerable()));
            });

            _controller = Container.Resolve<FavoritesController>();
        }

        [TestMethod]
        public async Task GetUserFavourites_ShouldReturnValues()
        {
            SignedInUserId = "nilesh.more@heathrow.com";
            var result = await _controller.Get();
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(OkNegotiatedContentResult<IEnumerable<Favourites>>));
            Assert.AreEqual(1, ((OkNegotiatedContentResult<IEnumerable<Favourites>>)result).Content.FirstOrDefault().FavouriteId);
        }

        [TestMethod]
        public async Task GetUserFavourites_ShouldNotReturnValues()
        {
            SignedInUserId = "";
            var testFavourites = GetTestFavourites();
            var result = await _controller.Get();
            Assert.IsInstanceOfType(result, typeof(OkNegotiatedContentResult<IEnumerable<Favourites>>));
            Assert.AreNotEqual(((OkNegotiatedContentResult<IEnumerable<Favourites>>)result).Content.Count(), testFavourites.Count());
        }

        [TestMethod]
        public async Task Post_ShouldReturnSameFavourite()
        {
            SignedInUserId = "nilesh.more@heathrow.com";
            //var favouriteBusinessLayer = new Mock<IFavouriteModule>();
            //favouriteBusinessLayer.Setup(x => x.Save(GetTestFavourites()[0]));
            var data = GetTestFavourites()[0];
            //var controller = new FavoritesController(favouriteBusinessLayer.Object);
            var result = _controller.Post(data);
            //var result = GetResult<IEnumerable<Favourites>>(await _controller.Post(data));
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task Post_ShouldNotReturnSameFavourite()
        {
            SignedInUserId = "nilesh.more@heathrow.com";
            var favouriteBusinessLayer = new Mock<IFavouriteModule>();
            favouriteBusinessLayer.Setup(x => x.Save(
                 new Favourites()
                 {
                     FavouriteId = 1,
                     FavouriteLink = new Menu()
                     {
                         MenuId = 1,
                         BusinessReportId = "1",
                         Description = "desc",
                         FavouritesDescription = "desc",
                         CssIcon = "1",
                         IsReport = false,
                         OperationalReportId = "2",
                         OrderId = 1,
                         Organization = "org",
                         ParentId = 1,
                         Tooltip = "test"
                     },
                     UserId = "1"
                 }
                ));
            var data = new Favourites
            {
                FavouriteId = 1,
                UserId = "user1"
            };
            var controller = new FavoritesController(favouriteBusinessLayer.Object);

            var result = await controller.Post(data);
            Assert.AreNotEqual(1, result);
        }

        private static List<Favourites> GetTestFavourites()
        {
            var testFavourites = new List<Favourites>
            {
                new Favourites
                {
                    FavouriteId = 1,
                    FavouriteLink = new Menu()
                    {
                        MenuId = 1,
                        BusinessReportId = "url",
                        Description = "desc",
                        FavouritesDescription = "desc",
                        CssIcon = "1",
                        IsReport = false,
                        OperationalReportId = "url",
                        OrderId = 1,
                        Organization = "org",
                        ParentId = 1,
                        Tooltip = "test"
                    },
                    UserId = "nilesh.more@heathrow.com"
                }
            };

            return testFavourites;
        }
    }
}
