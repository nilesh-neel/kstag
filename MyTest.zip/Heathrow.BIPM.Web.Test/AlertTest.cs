﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Hosting;
using System.Web.Http.Routing;
using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class AlertTest
    {

        /*  [TestMethod]
          public void GetAlert_ShouldReturnAlertValues()
          {
              var alertBusinessLayer = new Mock<IAlertsModule>();

              var lookupBusinessLayer = new Mock<ILookupModule>();

              alertBusinessLayer.Setup(x => x.GetAlerts("1"))
          .Returns(GetTestAlertList());

              var testAlert = GetTestAlertList();
              var controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);

              var result = controller.Get();
              Assert.AreEqual(testAlert.Id, result.Id + 1);
          }

          [TestMethod]
          public void Get_ShouldNotReturnAlertValues()
          {
              var alertBusinessLayer = new Mock<IAlertsModule>();

              var lookBusinessLayer = new Mock<ILookupModule>();

              alertBusinessLayer.Setup(x => x.GetAlerts("1"))
                  .Returns(GetTestAlertList());

              var testAlert = GetTestAlerts();
              var controller = new AlertsController(alertBusinessLayer.Object, lookBusinessLayer.Object);

              var result = controller.Get();
              Assert.AreNotEqual(testAlert, result);
          }

          [TestMethod]
          public void GetAlertsById()
          {

              var testAlert = GetTestAlerts();

              var alerts = new List<Alerts>();
              var mock = new Mock<IAlertsModule>();

              var lookupBusinessLayer = new Mock<ILookupModule>();

              lookupBusinessLayer.Setup(s => s.BagMeasureList).ToString();

              lookupBusinessLayer.Setup(s => s.BagFrequencyList).ToString();

              lookupBusinessLayer.Setup(s => s.BagOperationalAreaList).ToString();

              lookupBusinessLayer.Setup(s => s.BagOrganisationList).ToString();

              lookupBusinessLayer.Setup(s => s.BagThresholdList).ToString();

              lookupBusinessLayer.Setup(s => s.BagTopicList).ToString();

              lookupBusinessLayer.Setup(s => s.BagTimeWindowList).ToString();

              var BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var Frequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };

              mock.Setup(p => p.GetAlertsById("userid", 1)).Returns(Task.FromResult(
                  new Alerts()
                  {
                      AlertId = 1,
                      Description = "desc",
                      BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      CreatedBy = "test",
                      CreatedDate = DateTime.Now,
                      DateAndTime = DateTime.Now,
                      DisableAlert = false,
                      DisableNotification = false,
                      EndDate = DateTime.Now,
                      Frequency = "1",
                      IsEmail = false,
                      IsMobile = true,
                      IsOnScreen = true,
                      IsSubscribe = false,
                      Location = "1",
                      MandatoryOptional = 1,
                      Measure = "1",
                      ModifiedBy = "test",
                      ModifiedDate = DateTime.Now,
                      OperationalArea = "1",
                      Organization = "1",
                      ResponseType = 1,
                      SelectedFrequency = 1,
                      //  SelectedLocation.Ad new int[] { 1, 2 },
                      SelectedMeasure = 1,
                      // SelectedOperationalArea = new int[] { 1, 2 },
                      SelectedOrganisation = 1,
                      SelectedThreshold = 1,
                      SelectedTimeWindow = 1,
                      SelectedTopic = 1,
                      StartDate = DateTime.Now,
                      Threshold = "1",
                      ThresholdValue = "1",
                      Time = "1",
                      TimeWindow = 1,
                      Title = "title",
                      Topic = "test"
                  }));
              AlertsController alert = new AlertsController(mock.Object, lookupBusinessLayer.Object);
              var result = alert.Get(1);
              Assert.IsNotNull(result);
          }

          [TestMethod]
          public void GetAlertsById1()
          {
              var testAlert = GetTestAlerts();
              var _alerts = new List<Alerts>();
              var mock = new Mock<IAlertsModule>();

              var lookupBusinessLayer = new Mock<ILookupModule>();

              lookupBusinessLayer.Setup(s => s.BagMeasureList).ToString();//.Returns(() => new List<Lookup>() { new Lookup { LookupTypeName = "test", RowId = 1, Selected = 1 } });

              lookupBusinessLayer.Setup(s => s.BagFrequencyList).ToString();

              lookupBusinessLayer.Setup(s => s.BagOperationalAreaList).ToString();

              lookupBusinessLayer.Setup(s => s.BagOrganisationList).ToString();

              lookupBusinessLayer.Setup(s => s.BagThresholdList).ToString();

              lookupBusinessLayer.Setup(s => s.BagTopicList).ToString();

              lookupBusinessLayer.Setup(s => s.BagTimeWindowList).ToString();

              var BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };
              var Frequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } };

              mock.Setup(p => p.GetAlertsById("userid", 1)).Returns(Task.FromResult(
                  new Alerts()
                  {
                      AlertId = 1,
                      Description = "desc",
                      BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      CreatedBy = "test",
                      CreatedDate = DateTime.Now,
                      DateAndTime = DateTime.Now,
                      DisableAlert = false,
                      DisableNotification = false,
                      EndDate = DateTime.Now,
                      Frequency = "1",
                      IsEmail = false,
                      IsMobile = true,
                      IsOnScreen = true,
                      IsSubscribe = false,
                      Location = "1",
                      MandatoryOptional = 1,
                      Measure = "1",
                      ModifiedBy = "test",
                      ModifiedDate = DateTime.Now,
                      OperationalArea = "1",
                      Organization = "1",
                      ResponseType = 1,
                      SelectedFrequency = 1,
                      //  SelectedLocation = new int[] { 1, 2 },
                      SelectedMeasure = 1,
                      //  SelectedOperationalArea = new int[] { 1, 2 },
                      SelectedOrganisation = 1,
                      SelectedThreshold = 1,
                      SelectedTimeWindow = 1,
                      SelectedTopic = 1,
                      StartDate = DateTime.Now,
                      Threshold = "1",
                      ThresholdValue = "1",
                      Time = "1",
                      TimeWindow = 1,
                      Title = "title",
                      Topic = "test"
                  }));
              AlertsController alert = new AlertsController(mock.Object, lookupBusinessLayer.Object);
              var result1 = alert.Get(1);
              Assert.AreNotEqual(testAlert, result1);
          }

          [TestMethod]
          public void Get_ShouldReturnAlertNotification()
          {
              var alertBusinessLayer = new Mock<IAlertsModule>();

              var lookupBusinessLayer = new Mock<ILookupModule>();

              alertBusinessLayer.Setup(x => x.GetAlertNotification("user1"))
          .Returns(GetTestAlertList());

              var testAlert = GetTestAlertList();
              var controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);

              var result = controller.GetAlertNotification();
              Assert.AreEqual(testAlert.Id, result.Id - 1);
          }

          [TestMethod]
          public void Get_ShouldNotReturnAlertNotification()
          {
              var alertBusinessLayer = new Mock<IAlertsModule>();

              var lookupBusinessLayer = new Mock<ILookupModule>();

              alertBusinessLayer.Setup(x => x.GetAlertNotification("user1"))
          .Returns(GetTestAlertList());

              var testAlert = GetTestAlertList();
              var controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);

              var result = controller.GetAlertNotification();
              Assert.AreNotEqual(testAlert, result);
          }

          [TestMethod]
          public void InsertUpdate()
          {
              var testAlert = GetTestAlerts();
              var _alerts = new List<Alerts>();
              var mock = new Mock<IAlertsModule>();
              mock.Setup(p => p.InsertUpdate(
                  new Alerts()
                  {
                      AlertId = 1,
                      Description = "desc",
                      BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      CreatedBy = "test",
                      CreatedDate = DateTime.Now,
                      DateAndTime = DateTime.Now,
                      DisableAlert = false,
                      DisableNotification = false,
                      EndDate = DateTime.Now,
                      Frequency = "1",
                      IsEmail = false,
                      IsMobile = true,
                      IsOnScreen = true,
                      IsSubscribe = false,
                      Location = "1",
                      MandatoryOptional = 1,
                      Measure = "1",
                      ModifiedBy = "test",
                      ModifiedDate = DateTime.Now,
                      OperationalArea = "1",
                      Organization = "1",
                      ResponseType = 1,
                      SelectedFrequency = 1,
                      // SelectedLocation = new int[] { 1, 2 },
                      SelectedMeasure = 1,
                      //  SelectedOperationalArea = new int[] { 1, 2 },
                      SelectedOrganisation = 1,
                      SelectedThreshold = 1,
                      SelectedTimeWindow = 1,
                      SelectedTopic = 1,
                      StartDate = DateTime.Now,
                      Threshold = "1",
                      ThresholdValue = "1",
                      Time = "1",
                      TimeWindow = 1,
                      Title = "title",
                      Topic = "test"
                  }));
              AlertsController alert = new AlertsController(mock.Object, null);
              var result1 = alert.Post(new Alerts()
              {
                  AlertId = 1,
                  Description = "desc",
                  BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  CreatedBy = "test",
                  CreatedDate = DateTime.Now,
                  DateAndTime = DateTime.Now,
                  DisableAlert = false,
                  DisableNotification = false,
                  EndDate = DateTime.Now,
                  Frequency = "1",
                  IsEmail = false,
                  IsMobile = true,
                  IsOnScreen = true,
                  IsSubscribe = false,
                  Location = "1",
                  MandatoryOptional = 1,
                  Measure = "1",
                  ModifiedBy = "test",
                  ModifiedDate = DateTime.Now,
                  OperationalArea = "1",
                  Organization = "1",
                  ResponseType = 1,
                  SelectedFrequency = 1,
                  //  SelectedLocation = new int[] { 1, 2 },
                  SelectedMeasure = 1,
                  //  SelectedOperationalArea = new int[] { 1, 2 },
                  SelectedOrganisation = 1,
                  SelectedThreshold = 1,
                  SelectedTimeWindow = 1,
                  SelectedTopic = 1,
                  StartDate = DateTime.Now,
                  Threshold = "1",
                  ThresholdValue = "1",
                  Time = "1",
                  TimeWindow = 1,
                  Title = "title",
                  Topic = "test"
              });
              Assert.AreNotEqual(testAlert, result1);
          }

          [TestMethod]
          public void InsertUpdate1()
          {
              var testAlert = GetTestAlerts();
              var _alerts = new List<Alerts>();
              var mock = new Mock<IAlertsModule>();
              mock.Setup(p => p.InsertUpdate(
                  new Alerts()
                  {
                      AlertId = 1,
                      Description = "desc",
                      BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                      CreatedBy = "test",
                      CreatedDate = DateTime.Now,
                      DateAndTime = DateTime.Now,
                      DisableAlert = false,
                      DisableNotification = false,
                      EndDate = DateTime.Now,
                      Frequency = "1",
                      IsEmail = false,
                      IsMobile = true,
                      IsOnScreen = true,
                      IsSubscribe = false,
                      Location = "1",
                      MandatoryOptional = 1,
                      Measure = "1",
                      ModifiedBy = "test",
                      ModifiedDate = DateTime.Now,
                      OperationalArea = "1",
                      Organization = "1",
                      ResponseType = 1,
                      SelectedFrequency = 1,
                      // SelectedLocation = new int[] { 1, 2 },
                      SelectedMeasure = 1,
                      // SelectedOperationalArea = new int[] { 1, 2 },
                      SelectedOrganisation = 1,
                      SelectedThreshold = 1,
                      SelectedTimeWindow = 1,
                      SelectedTopic = 1,
                      StartDate = DateTime.Now,
                      Threshold = "1",
                      ThresholdValue = "1",
                      Time = "1",
                      TimeWindow = 1,
                      Title = "title",
                      Topic = "test"
                  }));
              AlertsController alert = new AlertsController(mock.Object, null);
              var result1 = alert.Put(new Alerts()
              {
                  AlertId = 1,
                  Description = "desc",
                  BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                  CreatedBy = "test",
                  CreatedDate = DateTime.Now,
                  DateAndTime = DateTime.Now,
                  DisableAlert = false,
                  DisableNotification = false,
                  EndDate = DateTime.Now,
                  Frequency = "1",
                  IsEmail = false,
                  IsMobile = true,
                  IsOnScreen = true,
                  IsSubscribe = false,
                  Location = "1",
                  MandatoryOptional = 1,
                  Measure = "1",
                  ModifiedBy = "test",
                  ModifiedDate = DateTime.Now,
                  OperationalArea = "1",
                  Organization = "1",
                  ResponseType = 1,
                  SelectedFrequency = 1,
                  // SelectedLocation = new int[] { 1, 2 },
                  SelectedMeasure = 1,
                  //   SelectedOperationalArea = new int[] { 1, 2 },
                  SelectedOrganisation = 1,
                  SelectedThreshold = 1,
                  SelectedTimeWindow = 1,
                  SelectedTopic = 1,
                  StartDate = DateTime.Now,
                  Threshold = "1",
                  ThresholdValue = "1",
                  Time = "1",
                  TimeWindow = 1,
                  Title = "title",
                  Topic = "test"
              });
              Assert.AreNotEqual(testAlert, result1);
          }

      */

        [TestMethod]
        public void Get_ShouldReturnAlertCount()
        {

            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlertCount("user1"))
        .Returns(AlertCount);
            var testAlert =1;
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/AlertCount");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/AlertCount");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.GetAlertNotification();
            Assert.AreNotEqual(testAlert, result);
        }

        [TestMethod]
        public void Update_ShouldReturnValue()
        {
            var testAlert = GetTestAlerts();
            var _alerts = new List<Alerts>();
            var mock = new Mock<IAlertsModule>();
            mock.Setup(p => p.InsertUpdate(
                new Alerts()
                {
                    AlertId = 1,
                    Description = "desc",
                    BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    DateAndTime = DateTime.Now,
                    DisableAlert = false,
                    DisableNotification = false,
                    EndDate = DateTime.Now,
                 
                    IsEmail = false,
                    IsMobile = true,
                    IsOnScreen = true,
                    IsSubscribe = false,
                  
                    MandatoryOptional = 1,
                 
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                  
                  
                    ResponseType = 1,
                    SelectedFrequency = 1,
                      // SelectedLocation = new int[] { 1, 2 },
                      SelectedMeasure = 1,
                      // SelectedOperationalArea = new int[] { 1, 2 },
                      SelectedOrganisation = 1,
                    SelectedThreshold = 1,
                    SelectedTimeWindow = 1,
                    SelectedTopic = 1,
                    StartDate = DateTime.Now,
                
                    ThresholdValue = "1",
                   
                    TimeWindow = 1,
                    Title = "title"
                    
                }));
            AlertsController alert = new AlertsController(mock.Object, null);
            var result1 = alert.Put(new Alerts()
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
               // Frequency = "1",
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
               // Location = "1",
                MandatoryOptional = 1,
              //  Measure = "1",
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
             //   OperationalArea = "1",
             //   Organization = "1",
                ResponseType = 1,
                SelectedFrequency = 1,
                // SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //   SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
              //  Threshold = "1",
                ThresholdValue = "1",
             //   Time = "1",
                TimeWindow = 1,
                Title = "title"
             //   Topic = "test"
            });
            Assert.AreNotEqual(testAlert, result1);
        }

        [TestMethod]
        public void Get_ShouldReturnAlertNotification()
        {

            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlertNotification("user1"))
        .Returns(GetTodaysAlert());
            var testAlert = GetTodaysAlert();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/AlertNotification");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/AlertNotification");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get();
            Assert.AreEqual(testAlert.Id, result.Id - 1);
        }

        [TestMethod]
        public void Get_ShouldNotReturnAlertNotification()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlertNotification("user1"))
        .Returns(GetTodaysAlert());
            var testAlert = GetTodaysAlert();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/AlertNotification");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/AlertNotification");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.GetAlertNotification();
            Assert.AreEqual(testAlert.Id, result.Id-1);
        }


        [TestMethod]
        public void TopicForMeasure_ShouldReturnValues()
        {
            var alertsBusinessLayer = new Mock<IAlertsModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            alertsBusinessLayer.Setup(x => x.GetTopicForMeasure("1"))
                .Returns(Task.FromResult(GetTestAlert()));

            var testNotification = GetTestAlert();
            var controller = new AlertsController(alertsBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = controller.TopicForMeasure("1");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TodaysAlert_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            alertBusinessLayer.Setup(x => x.GetTodaysAlert("1"))
        .Returns(GetTodaysAlert());

            var testAlert = GetTestAlertList();
            var controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = controller.TodaysAlert();
            Assert.AreEqual(testAlert.Id, result.Id -1);
        }

        [TestMethod]
        public void GetAlertById_ShouldReturnValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();

            alertBusinessLayer.Setup(x => x.GetAlertsById("Admin", 0))
                .Returns(Task.FromResult(GetTestMyAlertSettings()));

            var testAlert = GetTestAlert();
            var controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = controller.Get(0);
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void GetAlertByID_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlerts("1"))
        .Returns(GetTestAlertList());
            var testAlert = GetTestAlertList();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/AlertByID");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/AlertByID");
            Controller.ControllerContext = new System.Web.Http.Controllers.HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get(1);
            //Assert.AreEqual(testAlert.Id, result.Id -1);
        }

        [TestMethod]
        public void GetConfigureAlertByID_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlerts("1"))
          .Returns(GetTestAlertList());
            var testAlert = GetTestAlertList();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/ConfigureAlertByID");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/ConfigureAlertByID");
            Controller.ControllerContext = new System.Web.Http.Controllers.HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get(1);
            Assert.AreEqual(testAlert.Id, result.Id + 1);
        }


        [TestMethod]
        public void GetAlerts_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            alertBusinessLayer.Setup(x => x.GetAlerts("user1"))
        .Returns(GetTestAlertList());
            var testAlert = GetTestAlertList();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/GetAlert");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/GetAlert");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get();
            Assert.AreEqual(testAlert.Id, result.Id - 1);
        }


        [TestMethod]
        public void GetConfiguredAlert_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlerts("user1"))
          .Returns(GetTestAlertList());
            var testAlert = GetTestAlertList();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/GetConfiguredAlert");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/GetConfiguredAlert");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get();
            Assert.AreEqual(testAlert.Id, result.Id - 1);
        }



        [TestMethod]
        public void Post_ShouldReturnNotification()
        {
            var testAlert = GetTestAlertList();
            var _alert = new List<Alerts>();
            var mock = new Mock<IAlertsModule>();         
            mock.Setup(p => p.InsertUpdate(
                new Alerts()
                {
                    AlertId = 1,
                    Description = "desc",
                    BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    DateAndTime = DateTime.Now,
                    DisableAlert = false,
                    DisableNotification = false,
                    EndDate = DateTime.Now,
                 
                    IsEmail = false,
                    IsMobile = true,
                    IsOnScreen = true,
                    IsSubscribe = false,
                     MandatoryOptional = 1,
                  
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                   
                    
                    ResponseType = 1,
                    SelectedFrequency = 1,
                    // SelectedLocation = new int[] { 1, 2 },
                    SelectedMeasure = 1,
                    // SelectedOperationalArea = new int[] { 1, 2 },
                    SelectedOrganisation = 1,
                    SelectedThreshold = 1,
                    SelectedTimeWindow = 1,
                    SelectedTopic = 1,
                    StartDate = DateTime.Now,
                  
                    ThresholdValue = "1",
                  
                    TimeWindow = 1,
                    Title = "title",
                    
                }));
            AlertsController alerts = new AlertsController(mock.Object, null);          
            var result1 = alerts.Post(new Alerts()
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
             
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
               
                MandatoryOptional = 1,
              
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                
               
                ResponseType = 1,
                SelectedFrequency = 1,
                // SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                
                ThresholdValue = "1",
               
                TimeWindow = 1,
                Title = "title",
               
            });
            Assert.AreNotEqual(testAlert, result1);
        }



        private static List<Alerts> GetTestAlerts()
        {
            var testProducts = new List<Alerts>();
            testProducts.Add(new Alerts
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,             
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,            
                MandatoryOptional = 1,              
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,          
                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,                
                ThresholdValue = "1",             
                TimeWindow = 1,
                Title = "title",
               
            });
            testProducts.Add(new Alerts
            {
                AlertId = 2,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
               
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
               
                MandatoryOptional = 1,
             
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
              
               
                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //   SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                 ThresholdValue = "1",
                
                TimeWindow = 1,
                Title = "title",
               
            });
            testProducts.Add(new Alerts
            {
                AlertId = 3,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
              
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
               
                MandatoryOptional = 1,
              
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
               
                
                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //  SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                
                ThresholdValue = "1",
               
                TimeWindow = 1,
                Title = "title",
               
            });
            testProducts.Add(new Alerts
            {
                AlertId = 4,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
             
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
          
                MandatoryOptional = 1,
                
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
             
                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //  SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                
                ThresholdValue = "1",
               
                TimeWindow = 1,
                Title = "title",
               
            });

            return testProducts;
        }

        private static Task<IEnumerable<MyAlertSettings>> GetTestAlertList()
        {
            IEnumerable<MyAlertSettings> testProducts = new List<MyAlertSettings>()
            { new MyAlertSettings
            {
                AlertId = 1,
                Description = "desc",
   
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                MandatoryOptional = 1,
                Measure = "1",

                Threshold = "1",
                ThresholdValue = "1",
       
                Title = "title",
                Topic = "test"
            } };

            return Task.FromResult(testProducts);
        }


        private static Task<IEnumerable<TodaysAlert>> GetTodaysAlert()
        {
            IEnumerable<TodaysAlert> testProducts = new List<TodaysAlert>()
            { new TodaysAlert
            {
                AlertId = 4,
          
                CreatedDate = DateTime.Now,
       
                ResponseType = 1,
     
     
                Title = "title",
                Topic = "test"
            } };

            return Task.FromResult(testProducts);
        }

        public static Task<IEnumerable<Alerts>> GetAlertsList()
        {
            IEnumerable<Alerts> testProducts = new List<Alerts>()
            { new Alerts
            {
                 
                Title = "AlertMessage",                 
                AlertId = 1,
                ResponseType = 1
              //  Time = "1",     
             } };

            return Task.FromResult(testProducts);
        }
        private static Alerts GetTestAlert()
        {
            var testAlert = new Alerts()
            {
                BagFrequency = new List<Lookup>() { },
                CreatedBy = "David",
                AlertId = 1,
            };

            return testAlert;
        }
        private static MyAlertSettings GetTestMyAlertSettings()
        {
            var testAlert = new MyAlertSettings()
            {
                AlertId = 1,
                Description = "desc",

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                MandatoryOptional = 1,
                Measure = "1",

                Threshold = "1",
                ThresholdValue = "1",

                Title = "title",
                Topic = "test"
            };

            return testAlert;
        }
        private static Task<int> AlertCount()
        {
            return Task.FromResult(1);
        }
    }
}
