﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web.Http;
using System.Web.Http.Results;
using Heathrow.BIPM.Core.Entity;
using Unity;
using Unity.Injection;
using Unity.Lifetime;
using Unity.Registration;

namespace Heathrow.BIPM.Web.Test
{
    public abstract class BaseTest
    {
        protected UnityContainer Container;
        protected LifetimeResetter Resetter { get; set; }
        protected string SignedInUserId
        {
            get
            {
                var objClaimPrincipal = ClaimsPrincipal.Current.Identities.First();
                objClaimPrincipal.AddClaim(new Claim(ClaimTypes.Upn, "nilesh.more@heathrow.com"));
                return "nilesh.more@heathrow.com";
            }
            set
            {
                var objClaimPrincipal = ClaimsPrincipal.Current.Identities.First();
                objClaimPrincipal.AddClaim(new Claim(ClaimTypes.Upn, value));
            }
        }


        protected BaseTest()
        {
            Resetter = new LifetimeResetter();
            Container = new UnityContainer();

        }

        protected T GetResult<T>(IHttpActionResult result)
        {
            return ((OkNegotiatedContentResult<T>)result).Content;
        }

        [TestInitialize]
        public void OnTestSetup()
        {
            Resetter.Reset();
        }

        protected void RegisterResettableType<T>(params InjectionMember[] injectionMembers)
        {
            Container.RegisterType<T>(new ResettableLifetimeManager(Resetter), injectionMembers);
        }

        protected void RegisterResettableType<T>(Func<Action<Mock<T>>> onCreatedCallbackFactory) where T : class
        {
            RegisterResettableType<T>(new InjectionFactory(c => CreateMockInstance(onCreatedCallbackFactory)));
        }

        protected T CreateMockInstance<T>(Func<Action<Mock<T>>> onCreatedCallbackFactory) where T : class
        {
            var mock = new Mock<T>();
            var onCreatedCallback = onCreatedCallbackFactory();
            onCreatedCallback?.Invoke(mock);
            return mock.Object;
        }

        protected class LifetimeResetter
        {
            public event EventHandler<EventArgs> OnReset;

            public void Reset()
            {
                OnReset?.Invoke(this, EventArgs.Empty);
            }
        }

        protected class ResettableLifetimeManager : LifetimeManager
        {
            public ResettableLifetimeManager(LifetimeResetter lifetimeResetter)
            {
                lifetimeResetter.OnReset += (o, args) => instance = null;
            }

            private object instance;

            public override object GetValue()
            {
                return instance;
            }

            public override void SetValue(object newValue)
            {
                instance = newValue;
            }

            public override void RemoveValue()
            {
                instance = null;
            }
        }
    }
}
