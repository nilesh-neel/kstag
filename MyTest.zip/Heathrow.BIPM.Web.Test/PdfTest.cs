﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http.Results;
using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class PdfTest
    {

        [TestMethod]
        public async Task GetPdfMenu_ShouldReturnValues()
        {
            var pdfBusinessLayer = new Mock<IPdfModule>();

            pdfBusinessLayer.Setup(x => x.Getpdfmenu(19))
                .Returns(GetTestPdfList());

            var testPdf = GetTestPdf();
            var controller = new PdfController(pdfBusinessLayer.Object);

            var response = await controller.Get(19) ;
            Assert.AreNotEqual(((OkNegotiatedContentResult<IEnumerable<PdfMappings>>)response).Content, testPdf.Count);
        }

        [TestMethod]
        public async Task GetPdfMenu_ShouldNotReturnValues()
        {
            var pdfBusinessLayer = new Mock<IPdfModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser() { Id = "user1", Name = "Admin" }));

            pdfBusinessLayer.Setup(x => x.Getpdfmenu(1))
                .Returns(GetTestPdfList());

            var testPdf = GetTestPdf();
            var controller = new PdfController(pdfBusinessLayer.Object);

            var result =await  controller.Get(1);
            Assert.AreNotEqual(testPdf, result);
        }

        private static IList<PdfMappings> GetTestPdf()
        {
            var testPdf = new List<PdfMappings>
            {
                new PdfMappings()
                {
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    MenuId = 19,
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    PageNo = "4",
                    PdfId = 1,
                    PdfName = "sample.pdf"
                }
            };

            return testPdf;
        }

        private static Task<IEnumerable<PdfMappings>> GetTestPdfList()
        {
            IEnumerable<PdfMappings> testPdf = new List<PdfMappings>()
            { new PdfMappings()
                {
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    MenuId = 19,
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    PageNo = "4",
                    PdfId = 1,
                    PdfName = "sample.pdf"
                }
            };

            return Task.FromResult(testPdf);
        }
    }
}
