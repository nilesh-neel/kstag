﻿using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Moq;
using Heathrow.BIPM.Api.Controllers;
using System.Collections.Generic;


namespace Heathrow.BIPM.Web.Test
{
    [TestClass]
    public class AuthiApiTest
    {
        [TestMethod]
        public async Task GetPbiToken()
        {
            Mock<IBpmPowerBi> IBpmBusinessLayer = new Mock<IBpmPowerBi>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser { Id = "user2", Name = "TestUser" }));

            IBpmBusinessLayer.Setup(x => x.EmbedReportV2(2, 1))
                .Returns(Task.FromResult(TestCollection()));

            var controller = new AuthApiController(IBpmBusinessLayer.Object);
            var testAuthApi = TestCollection();
            IHttpActionResult actionResult = await controller.GetPbiToken(2, 1);
            Assert.IsNotNull(actionResult);
        }

        private static List<PowerBiEmbedConfig> TestCollection() =>
           new List<PowerBiEmbedConfig>
           {
                new PowerBiEmbedConfig
                {
                    EmbedToken="TestToken",
                    EmbedUrl=new Uri("https://abc.com"),
                    Id="1",
                    ErrorMessage="No error",
                    PowerBIType="1",
                    UserName="test"
                }
           };

    }
}

