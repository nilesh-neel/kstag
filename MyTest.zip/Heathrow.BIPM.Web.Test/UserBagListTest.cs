﻿//----------------------------------------------------------------------
//Class Name   : UserBagListTest.cs 
//Purpose      : This is the unit case implementation file for BagList module. 
//Created By   : Vignesh AshokKumar
//Created Date : 21/Dec/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;

namespace Heathrow.BIPM.Test
{
    /// <summary>
    /// 
    /// </summary>
    [TestClass]
    public class UserBagListTest
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Fetching the Existing BagTags and BagTags Count of the Logged-in User")]
        public async Task Get_ShouldReturnExistingBagtags()
        {
            Mock<IBagListModule> baglistBusinessLayer = new Mock<IBagListModule>();

            baglistBusinessLayer.Setup(x => x.GetUserExistingbagtags("lawrencemckensy@heathrow.com"))
                .Returns(ExistingBagtags());

            var controller = new UserBagListController(baglistBusinessLayer.Object);
            var testBagList = TestBagListCollection();
            IHttpActionResult actionResult = await controller.Get("lawrencemckensy@heathrow.com");
            Assert.AreEqual(((OkNegotiatedContentResult<string>)actionResult).Content, testBagList.BagTagsJson);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Fetching the Existing BagTags and BagTags Count of the Logged-in User")]
        public async Task Get_ShouldNotReturnExistingBagtags()
        {
            Mock<IBagListModule> bagListBusinessLayer = new Mock<IBagListModule>();

            bagListBusinessLayer.Setup(x => x.GetUserExistingbagtags("lawrencemckensy@heathrow.com"))
                .Returns(ExistingBagtags());

            var controller = new UserBagListController(bagListBusinessLayer.Object);
            var testBagList = TestBagListCollection();
            IHttpActionResult actionResult = await controller.Get("lawrencemckensy@heathrow.com");
            Assert.AreNotEqual(((OkNegotiatedContentResult<string>)actionResult).Content, testBagList);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Saving the Added BagTags selected by the Logged-in User")]
        public async Task Post_ShouldReturnSameBagTags()
        {
            Mock<IBagListModule> bagListBusinessLayer = new Mock<IBagListModule>();

            var userModule = new Mock<IUserModule>();

            bagListBusinessLayer.Setup(x => x.SaveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", ""))
                .Returns(ExistingBagtags());

            var controller = new UserBagListController(bagListBusinessLayer.Object);
            var testBagList = TestBagListCollection();

            var data = new BagList
            {
                BagTagsJson = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]",
                //UserId = 2,
            };

            IHttpActionResult actionResult = await controller.Post(data);
            Assert.AreEqual(((OkNegotiatedContentResult<string>)actionResult).Content, testBagList.BagTagsJson);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Saving the Added BagTags selected by the Logged-in User")]
        public async Task Post_ShouldNotReturnSameBagTags()
        {
            Mock<IBagListModule> bagListBusinessLayer = new Mock<IBagListModule>();

            bagListBusinessLayer.Setup(x => x.SaveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177511,3589219522']}]", ""))
          .Returns(ExistingBagtags());

            var controller = new UserBagListController(bagListBusinessLayer.Object);
            var testBagList = TestBagListCollection();

            var data = new BagList
            {
                BagTagsJson = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177511,3589219522']}]",
            };

            IHttpActionResult actionResult = await controller.Post(data);
            Assert.AreNotEqual(((OkNegotiatedContentResult<string>)actionResult).Content, testBagList);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Deleting/Removing BagTags selected by the Logged-in User")]
        public async Task Delete_ShouldReturnSelectedBagtags()
        {
            Mock<IBagListModule> bagListBusinessLayer = new Mock<IBagListModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser { Id = "user1", Name = "Admin" }));

            bagListBusinessLayer.Setup(x => x.RemoveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", ""))
                .Returns(ExistingBagtags());

            var controller = new UserBagListController(bagListBusinessLayer.Object);
            var testBagList = ExistingBagtags();

            IHttpActionResult actionResult = await controller.Delete("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]");

            Assert.AreEqual(((OkNegotiatedContentResult<string>)actionResult).Content, testBagList.Result);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Deleting/Removing BagTags selected by the Logged-in User")]
        public async Task Delete_ShouldNotReturnSelectedBagtags()
        {
            Mock<IBagListModule> bagListBusinessLayer = new Mock<IBagListModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser { Id = "user1", Name = "Admin" }));

            bagListBusinessLayer.Setup(x => x.RemoveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", ""))
                .Returns(ExistingBagtags());

            var controller = new UserBagListController(bagListBusinessLayer.Object);
            var testBagList = TestBagListCollection();

            IHttpActionResult actionResult = await controller.Delete("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]");
            Assert.AreNotEqual(((OkNegotiatedContentResult<string>)actionResult).Content, testBagList);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static BagList TestBagListCollection()
        {
            return new BagList()
            {
                BagTagsJson = "[{'TableName':'dummyBagItem','ColumnName':'dummyTagNumber','ColumnValue':['3589177579,3589219538']}]",
                UserId = 2,
                BagListId = 4,
                BagTags = "3589219568",
                OtherUserId = 3,
                UpdatedDate = DateTime.Now,
                UserEmail = "lawrencemckensy@heathrow.com",
                UserFirstName = "Lawrence",
                UserLastName = "Mckensy",
                UserOrg = "TestCompany",
                UserRole = "Admin",
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static Task<string> ExistingBagtags()
        {
            return Task.FromResult("[{'TableName':'dummyBagItem','ColumnName':'dummyTagNumber','ColumnValue':['3589177579,3589219538']}]");
        }

    }
}
