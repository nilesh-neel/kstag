﻿using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class NotificationTest
    {
        [TestMethod]
        public async Task GetNotification_ShouldReturnValues()
        {
            var notifyBusinessLayer = new Mock<INotificationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            notifyBusinessLayer.Setup(x => x.GetUsersNotification("user1@xy.com"))
          .Returns(Task.FromResult(GetTestNotificationList().AsEnumerable()));

            var testNotification = GetTestNotificationList().AsEnumerable();

            var controller = new NotificationsController(notifyBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = await controller.Get();
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetNotification_ShouldNotReturnValues()
        {
            var notifyBusinessLayer = new Mock<INotificationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            lookupBusinessLayer.Setup(s => s.BagFrequencyList);
               
            notifyBusinessLayer.Setup(x => x.GetUsersNotification("user1@xy.com"))
                .Returns(Task.FromResult(GetTestNotificationList().AsEnumerable()));

            var testNotification = GetTestNotificationList().AsEnumerable();
            var controller = new NotificationsController(notifyBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = await controller.Get();

            Assert.AreNotEqual(testNotification, result);
        }

        [TestMethod]
        public async Task GetScrollingNotification_ShouldReturnValues()
        {
            var notifyBusinessLayer = new Mock<INotificationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            notifyBusinessLayer.Setup(x => x.GetScrollingNotification("user1@heathrow.com"))
                .Returns(Task.FromResult((new List<Notification>()
                { new Notification() {
                    BagFrequency = new List<Lookup>() { },
                    CreatedBy = "David"
                }
                }).AsEnumerable()));

            var testNotification = GetTestNotification();
            var controller = new NotificationsController(notifyBusinessLayer.Object, lookupBusinessLayer.Object);
            var result = await controller.GetScrollingNotification();
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetScrollingNotification_ShouldNotReturnValues()
        {
            var notifyBusinessLayer = new Mock<INotificationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            notifyBusinessLayer.Setup(x => x.GetScrollingNotification("user1@heathrow.com"))
                .Returns(Task.FromResult((new List<Notification>()
                { new Notification() {
                    BagFrequency = new List<Lookup>() { },
                    CreatedBy = "David"
                }
                }).AsEnumerable()));

            var testNotification = GetTestNotification();
            var controller = new NotificationsController(notifyBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = await controller.GetScrollingNotification() as Notification;
            Assert.IsNull(result);
        }

        [TestMethod]
        public void Post_ShouldReturnNotification()
        {          
            var testNotification = GetTestNotificationList();
            var _notification = new List<Notification>();
            var mock = new Mock<INotificationModule>();
            var rep = new Mock<INotification>();
            rep.Setup(p => p.InsertUpdate(
                new Notification()
                {
                    NotificationId = 1,
                    Description = "desc",
                    BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    DateAndTime = DateTime.Now,
                    DisableNotification = false,
                    EndDate = DateTime.Now,
                    IsEmail = false,
                    IsMobile = true,
                    IsOnScreen = true,
                    IsSubscribe = false,
                    Location = "1",
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    OperationalArea = "1",
                    Organisation = "1",
                    ResponseType = 1,
                    SelectedMeasure = 1,
                    SelectedOrganisation = 1,
                    SelectedThreshold = 1,
                    SelectedTimeWindow = 1,
                    SelectedTopic = 1,
                    StartDate = DateTime.Now,
                    Topic = "test"
                }));
            mock.Setup(p => p.InsertUpdate(
                new Notification()
                {
                    NotificationId = 1,
                    Description = "desc",
                    BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    DateAndTime = DateTime.Now,  
                    DisableNotification = false,
                    EndDate = DateTime.Now,      
                    IsEmail = false,
                    IsMobile = true,
                    IsOnScreen = true,
                    IsSubscribe = false,
                    Location = "1",            
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    OperationalArea = "1",
                    Organisation = "1",
                    ResponseType = 1,                    
                    SelectedMeasure = 1,      
                    SelectedOrganisation = 1,
                    SelectedThreshold = 1,
                    SelectedTimeWindow = 1,
                    SelectedTopic = 1,
                    StartDate = DateTime.Now,
                    Topic = "test"
                }));
            NotificationsController notification = new NotificationsController(mock.Object, null);
            NotificationModule notificationModule = new NotificationModule(rep.Object);
            var success=notificationModule.InsertUpdate(new Notification()
            {
                NotificationId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,

                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",


                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                OperationalArea = "1",
                Organisation = "1",
                ResponseType = 1,
                SelectedMeasure = 1,
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                Topic = "test"
            });
            var result1 = notification.Post(new Notification()
            {
                NotificationId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,

                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",


                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                OperationalArea = "1",
                Organisation = "1",
                ResponseType = 1,
                SelectedMeasure = 1,
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                Topic = "test"
            });                      
            Assert.AreNotEqual(testNotification, result1);
        }

        [TestMethod]
        public void Post_ShouldNotReturnNotification()
        {
            var notifyBusinessLayer = new Mock<INotificationModule>();
            notifyBusinessLayer.Setup(x => x.InsertUpdate(
                 new Notification()
                 {
                     BagFrequency = new List<Lookup>() { },
                     CreatedBy = "David",
                     NotificationId = 0,
                 }
                ));
            var data = new Notification
            {
                BagFrequency = new List<Lookup>() { },
                CreatedBy = "David",
                NotificationId = 1,
            };
            var controller = new NotificationsController(notifyBusinessLayer.Object, null);

            var result = controller.Post(data);
            Assert.AreNotEqual(data, result);
        }

  

        [TestMethod]
        public void GetNotificationById_ShouldReturnValues()
        {
            var notifyBusinessLayer = new Mock<INotificationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            notifyBusinessLayer.Setup(x => x.GetNotificationById("Admin", 1))
                .Returns(Task.FromResult(GetTestNotification()));

            var testNotification = GetTestNotification();
            var controller = new NotificationsController(notifyBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = controller.Get(1);
            Assert.IsNotNull(result);
        }


        [TestMethod]
        public void NotificationById_ShouldReturnValues()
        {
            var notifyBusinessLayer = new Mock<INotificationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            notifyBusinessLayer.Setup(x => x.GetNotificationById("Admin", 0))
                .Returns(Task.FromResult(GetTestNotification()));

            var testNotification = GetTestNotification();
            var controller = new NotificationsController(notifyBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = controller.Get(0);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetNotificationById_ShouldNotReturnValues()
        {
            var notifyBusinessLayer = new Mock<INotificationModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            notifyBusinessLayer.Setup(x => x.GetNotificationById("2", 1))
                .Returns(Task.FromResult(new Notification()
                 {
                     BagFrequency = new List<Lookup>() { },
                     CreatedBy = "David"
                 }
                ));

            var testNotification = GetTestNotification();
            var controller = new NotificationsController(notifyBusinessLayer.Object, lookupBusinessLayer.Object);

            var result =   controller.Get();
            Assert.AreNotEqual(result,testNotification);
        }


        private static Notification GetTestNotification()
        {
            var testNotification = new Notification()
            {
                BagFrequency = new List<Lookup>() { },
                BagLocation=new List<Lookup> { },
                BagOperationalArea=new List<Lookup> { },
                CreatedBy = "David",
                NotificationId = 1,
            };

            return testNotification;
        }

        private static List<Notification> GetTestNotificationList()
        {
            var testNotification = new List<Notification>
            {
             new Notification
            {
                BagFrequency = new List<Lookup>() { },
                CreatedBy = "David",
                NotificationId = 1,
            },
            };

            return testNotification;
        }
    }
}
